As this is my first time coding with Ruby, please excuse any errors. I attempted to teach myself the language as going along. 

Q1 through Q6 are all seperate rake files. 

I have zipped the whole file I used for coding and testing, the directory for the questions are 
../myapp/lib/tasks

Each file is named after the question. 

To call each question an example will be shown below:

cd myapp

rake Q1:Q1
rake Q2:C
rake Q3:B
rake Q4:E
rake Q5:C
rake Q6:B

							----------------- Trying to approach the challenge -----------------

At first, I started with trying to use arrays because that is what I am familiar with in previous languages. 

Question 1 started with a simple array that printed a to the console.

jobs = ["a"]
puts jobs
puts ""

Then on question 2, I used the push method to add b and c to the array and print abc to the console.
jobs.push("b", "c")
jobs.each{|jobs| puts jobs}
puts ""

It was when I tried to have b depend on c, this could not happen unless I hard coded the array to be printed to console like so below. 
puts jobs[0]
puts jobs[2]
puts jobs[1]
puts ""


When it came to question 3 onwards, trying to get array values to depend on each other does not work. After some time in researching, I found that rake uses ruby coding language 
to perform tasks that can have dependences. I then started to learn how to get tasks to run and have different tasks to depend on each other.
